package eeg.ui;

import eeg.analysis.JitterAnalyzer;
import eeg.experiment.ExperimentConfig;
import eeg.experiment.ExperimentManager;
import eeg.log.EventLogger;
import eeg.stimulus.VisualStimulus;
import javafx.application.Platform;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.chart.XYChart;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Map;

/**
 * Главное окно приложения.
 * Содержит три вкладки:
 * 1. Управление экспериментом (запуск, стимул, прогресс)
 * 2. Настройки (параметры стимуляции и эмуляции)
 * 3. Анализ логов (статистика, гистограмма, таблица событий)
 */
public class MainWindow {

    private static final String ACCENT_COLOR = "#4F8EF7";
    private static final String SUCCESS_COLOR = "#34C759";
    private static final String WARNING_COLOR = "#FF9500";
    private static final String DANGER_COLOR = "#FF3B30";
    private static final String BG_DARK = "#1C1C1E";
    private static final String BG_CARD = "#2C2C2E";
    private static final String BG_INPUT = "#3A3A3C";
    private static final String TEXT_PRIMARY = "#FFFFFF";
    private static final String TEXT_SECONDARY = "#AEAEB2";

    private final ExperimentManager manager;
    private final ExperimentConfig config;
    private final EventLogger logger;

    // Experiment tab controls
    private Label statusLabel;
    private Label stimulusDisplay;
    private ProgressBar progressBar;
    private Button startStopButton;
    private Label progressLabel;
    private Label markerCountLabel;
    private Label meanDelayLabel;
    private Circle statusIndicator;
    private Label modeLabel;

    // Settings controls
    private Spinner<Integer> stimulusCountSpinner;
    private Spinner<Integer> intervalSpinner;
    private Spinner<Integer> durationSpinner;
    private ToggleGroup modeToggle;
    private RadioButton emulationRadio;
    private RadioButton realRadio;
    private VBox emulationParamsBox;
    private Spinner<Double> baseDelaySpinner;
    private Spinner<Double> jitterStdSpinner;
    private Spinner<Double> outlierProbSpinner;
    private Spinner<Double> outlierMaxSpinner;
    private TextField portField;
    private TextField experimentIdField;
    private TextField logDirField;

    // Analysis tab controls
    private TableView<EventLogger.LogEntry> logTable;
    private ObservableList<EventLogger.LogEntry> logData;
    private Label statCount, statMean, statStd, statMin, statMax, statP95;
    private BarChart<String, Number> jitterChart;

    public MainWindow(ExperimentManager manager, ExperimentConfig config, EventLogger logger) {
        this.manager = manager;
        this.config = config;
        this.logger = logger;
    }

    public Scene createScene() {
        BorderPane root = new BorderPane();
        root.setStyle("-fx-background-color: " + BG_DARK + ";");

        // Top bar
        root.setTop(createTopBar());

        // Tab pane
        TabPane tabPane = new TabPane();
        tabPane.setStyle("-fx-tab-min-height: 42px; -fx-tab-max-height: 42px; -fx-background-color: transparent;");

        Tab experimentTab = createExperimentTab();
        Tab settingsTab = createSettingsTab();
        Tab analysisTab = createAnalysisTab();

        tabPane.getTabs().addAll(experimentTab, settingsTab, analysisTab);
        tabPane.setTabClosingPolicy(TabPane.TabClosingPolicy.UNAVAILABLE);

        root.setCenter(tabPane);
        root.setBottom(createStatusBar());

        // Listen to log events for live table update
        logger.addListener(entry -> Platform.runLater(() -> {
            if (logData != null) logData.add(entry);
        }));

        // Wire up experiment callbacks
        manager.setCallbacks(
                this::onStimulusPresented,
                this::onStimulusHidden,
                this::onExperimentFinished,
                this::onStatusChanged,
                this::onProgressChanged
        );

        Scene scene = new Scene(root, 1280, 800);
        applyGlobalStyle(scene);
        return scene;
    }

    // ── TOP BAR ─────────────────────────────────────────────────────────────

    private HBox createTopBar() {
        HBox bar = new HBox(12);
        bar.setAlignment(Pos.CENTER_LEFT);
        bar.setPadding(new Insets(16, 24, 16, 24));
        bar.setStyle("-fx-background-color: " + BG_CARD + "; -fx-border-color: #3A3A3C; -fx-border-width: 0 0 1 0;");

        // Logo / title
        VBox titleBox = new VBox(2);
        Label title = new Label("EEG Experiment Suite");
        title.setFont(Font.font("System", FontWeight.BOLD, 18));
        title.setTextFill(Color.WHITE);
        Label subtitle = new Label("НИИ Нейронаук и Медицины — Лаборатория дифференциальной психофизиологии");
        subtitle.setFont(Font.font("System", 11));
        subtitle.setTextFill(Color.web(TEXT_SECONDARY));
        titleBox.getChildren().addAll(title, subtitle);

        HBox.setHgrow(titleBox, Priority.ALWAYS);

        // Mode badge - исправлено: убран text block, используется обычная строка
        modeLabel = new Label(config.isEmulationMode() ? "⚡ ЭМУЛЯЦИЯ" : "🔌 РЕАЛЬНЫЙ");
        String modeStyle = "-fx-background-color: " + (config.isEmulationMode() ? WARNING_COLOR : SUCCESS_COLOR) +
                "; -fx-text-fill: white; -fx-font-weight: bold; -fx-font-size: 11px; " +
                "-fx-padding: 4 10 4 10; -fx-background-radius: 8;";
        modeLabel.setStyle(modeStyle);

        // Status indicator dot
        statusIndicator = new Circle(6);
        statusIndicator.setFill(Color.web("#8E8E93"));

        bar.getChildren().addAll(titleBox, statusIndicator, modeLabel);
        return bar;
    }

    // ── EXPERIMENT TAB ───────────────────────────────────────────────────────

    private Tab createExperimentTab() {
        Tab tab = new Tab("▶  Эксперимент");

        BorderPane content = new BorderPane();
        content.setPadding(new Insets(24));
        content.setStyle("-fx-background-color: " + BG_DARK + ";");

        // Left: stimulus display
        VBox stimulusPanel = createStimulusPanel();
        content.setCenter(stimulusPanel);

        // Right: controls + live stats
        VBox controlPanel = createControlPanel();
        controlPanel.setPrefWidth(300);
        content.setRight(controlPanel);

        tab.setContent(content);
        return tab;
    }

    private VBox createStimulusPanel() {
        VBox panel = new VBox(20);
        panel.setAlignment(Pos.CENTER);
        panel.setPadding(new Insets(0, 24, 0, 0));

        // Stimulus display area
        StackPane displayArea = new StackPane();
        displayArea.setMinHeight(360);
        String displayStyle = "-fx-background-color: #000000; -fx-background-radius: 16; " +
                "-fx-border-color: #3A3A3C; -fx-border-radius: 16; -fx-border-width: 1;";
        displayArea.setStyle(displayStyle);

        stimulusDisplay = new Label("Ожидание запуска...");
        stimulusDisplay.setFont(Font.font("System", FontWeight.BOLD, 64));
        stimulusDisplay.setTextFill(Color.web("#8E8E93"));
        stimulusDisplay.setWrapText(true);
        stimulusDisplay.setAlignment(Pos.CENTER);
        displayArea.getChildren().add(stimulusDisplay);
        VBox.setVgrow(displayArea, Priority.ALWAYS);

        // Progress section
        VBox progressSection = new VBox(8);
        HBox progressHeader = new HBox();
        Label progressTitle = new Label("Прогресс эксперимента");
        progressTitle.setTextFill(Color.web(TEXT_SECONDARY));
        progressTitle.setFont(Font.font("System", 13));
        progressLabel = new Label("0 / 0");
        progressLabel.setTextFill(Color.web(TEXT_PRIMARY));
        progressLabel.setFont(Font.font("System", FontWeight.BOLD, 13));
        progressHeader.getChildren().addAll(progressTitle, createSpacer(), progressLabel);

        progressBar = new ProgressBar(0);
        progressBar.setMaxWidth(Double.MAX_VALUE);
        progressBar.setPrefHeight(8);
        progressBar.setStyle("-fx-accent: " + ACCENT_COLOR + ";");
        progressSection.getChildren().addAll(progressHeader, progressBar);

        panel.getChildren().addAll(displayArea, progressSection);
        return panel;
    }

    private VBox createControlPanel() {
        VBox panel = new VBox(16);
        panel.setAlignment(Pos.TOP_CENTER);

        // Start/Stop button
        startStopButton = new Button("▶  Запустить");
        startStopButton.setMaxWidth(Double.MAX_VALUE);
        startStopButton.setPrefHeight(52);
        startStopButton.setFont(Font.font("System", FontWeight.BOLD, 15));
        startStopButton.setStyle(primaryButtonStyle(ACCENT_COLOR));
        startStopButton.setOnAction(e -> onStartStop());

        // Live stats cards
        VBox statsCard = createCard("📊 Статистика сессии");
        markerCountLabel = createStatRow(statsCard, "Маркеров отправлено", "0");
        meanDelayLabel = createStatRow(statsCard, "Средняя задержка", "—");

        // Keyboard hint
        VBox hintCard = createCard("⌨  Управление");
        Label hint1 = new Label("ПРОБЕЛ — ответ испытуемого");
        Label hint2 = new Label("ESC — остановить эксперимент");
        hint1.setTextFill(Color.web(TEXT_SECONDARY));
        hint2.setTextFill(Color.web(TEXT_SECONDARY));
        hint1.setFont(Font.font("System", 12));
        hint2.setFont(Font.font("System", 12));
        hintCard.getChildren().addAll(hint1, hint2);

        // Status label
        statusLabel = new Label("Готов к запуску");
        statusLabel.setTextFill(Color.web(TEXT_SECONDARY));
        statusLabel.setFont(Font.font("System", 12));
        statusLabel.setWrapText(true);
        statusLabel.setMaxWidth(Double.MAX_VALUE);

        panel.getChildren().addAll(startStopButton, statsCard, hintCard, statusLabel);

        // Keyboard handler placeholder (set on scene)
        Platform.runLater(() -> {
            if (startStopButton.getScene() != null) {
                startStopButton.getScene().setOnKeyPressed(e -> {
                    switch (e.getCode()) {
                        case SPACE -> manager.recordKeyResponse("SPACE");
                        case ESCAPE -> onStartStop();
                        default -> {}
                    }
                });
            }
        });

        return panel;
    }

    // ── SETTINGS TAB ────────────────────────────────────────────────────────

    private Tab createSettingsTab() {
        Tab tab = new Tab("⚙  Настройки");
        ScrollPane scroll = new ScrollPane();
        scroll.setFitToWidth(true);
        scroll.setStyle("-fx-background-color: " + BG_DARK + "; -fx-border-color: transparent;");

        VBox content = new VBox(20);
        content.setPadding(new Insets(24));
        content.setStyle("-fx-background-color: " + BG_DARK + ";");

        // Stimulus parameters
        VBox stimCard = createCard("🎯 Параметры стимуляции");
        stimulusCountSpinner = createIntSpinner(1, 100, config.getStimulusCount());
        intervalSpinner = createIntSpinner(500, 10000, (int) config.getStimulusIntervalMs());
        durationSpinner = createIntSpinner(100, 5000, (int) config.getStimulusDurationMs());
        addFormRow(stimCard, "Количество стимулов:", stimulusCountSpinner);
        addFormRow(stimCard, "Интервал между стимулами (мс):", intervalSpinner);
        addFormRow(stimCard, "Длительность стимула (мс):", durationSpinner);

        // Mode selection
        VBox modeCard = createCard("🔧 Режим работы");
        modeToggle = new ToggleGroup();
        emulationRadio = createRadio("Эмуляция (для тестирования без ЭЭГ-оборудования)", modeToggle);
        realRadio = createRadio("Реальный (отправка меток на ЭЭГ-усилитель через порт)", modeToggle);
        emulationRadio.setSelected(config.isEmulationMode());
        realRadio.setSelected(!config.isEmulationMode());
        modeCard.getChildren().addAll(emulationRadio, realRadio);

        // Emulation params
        emulationParamsBox = createCard("⚡ Параметры эмуляции джиттера");
        baseDelaySpinner = createDoubleSpinner(0, 100, config.getEmulationBaseDelayMs(), 0.5);
        jitterStdSpinner = createDoubleSpinner(0, 50, config.getEmulationJitterStdMs(), 0.1);
        outlierProbSpinner = createDoubleSpinner(0, 1, config.getEmulationOutlierProbability(), 0.01);
        outlierMaxSpinner = createDoubleSpinner(5, 500, config.getEmulationOutlierMaxMs(), 5);
        addFormRow(emulationParamsBox, "Базовая задержка (мс):", baseDelaySpinner);
        addFormRow(emulationParamsBox, "СКО джиттера (мс):", jitterStdSpinner);
        addFormRow(emulationParamsBox, "Вероятность выброса (0–1):", outlierProbSpinner);
        addFormRow(emulationParamsBox, "Макс. задержка выброса (мс):", outlierMaxSpinner);
        emulationParamsBox.setVisible(config.isEmulationMode());
        emulationParamsBox.setManaged(config.isEmulationMode());

        // Real mode params
        VBox realCard = createCard("🔌 Параметры порта");
        portField = createTextField(config.getPortName());
        addFormRow(realCard, "COM-порт:", portField);

        // Session params
        VBox sessionCard = createCard("📁 Сессия и логирование");
        experimentIdField = createTextField(config.getExperimentId());
        logDirField = createTextField(config.getLogDirectory());
        Button browseBtn = new Button("Обзор...");
        browseBtn.setStyle(secondaryButtonStyle());
        browseBtn.setOnAction(e -> {
            javafx.stage.DirectoryChooser dc = new javafx.stage.DirectoryChooser();
            dc.setTitle("Выбор папки для логов");
            File dir = dc.showDialog(null);
            if (dir != null) logDirField.setText(dir.getAbsolutePath());
        });
        HBox logDirRow = new HBox(8, logDirField, browseBtn);
        HBox.setHgrow(logDirField, Priority.ALWAYS);
        addFormRow(sessionCard, "Идентификатор эксперимента:", experimentIdField);
        addFormRow(sessionCard, "Папка для логов:", logDirRow);

        // Apply button
        Button applyBtn = new Button("✓  Применить настройки");
        applyBtn.setStyle(primaryButtonStyle(SUCCESS_COLOR));
        applyBtn.setPrefHeight(44);
        applyBtn.setMaxWidth(Double.MAX_VALUE);
        applyBtn.setOnAction(e -> applySettings());

        // Toggle emulation params visibility
        emulationRadio.setOnAction(e -> {
            emulationParamsBox.setVisible(true);
            emulationParamsBox.setManaged(true);
        });
        realRadio.setOnAction(e -> {
            emulationParamsBox.setVisible(false);
            emulationParamsBox.setManaged(false);
        });

        content.getChildren().addAll(stimCard, modeCard, emulationParamsBox, realCard, sessionCard, applyBtn);
        scroll.setContent(content);
        tab.setContent(scroll);
        return tab;
    }

    // ── ANALYSIS TAB ────────────────────────────────────────────────────────

    private Tab createAnalysisTab() {
        Tab tab = new Tab("📈 Анализ");

        VBox content = new VBox(16);
        content.setPadding(new Insets(24));
        content.setStyle("-fx-background-color: " + BG_DARK + ";");

        // Toolbar
        HBox toolbar = new HBox(12);
        toolbar.setAlignment(Pos.CENTER_LEFT);
        Button refreshBtn = createToolbarButton("↻  Обновить");
        Button exportCsvBtn = createToolbarButton("📄  Экспорт CSV");
        Button exportReportBtn = createToolbarButton("📊  Экспорт отчёта");
        refreshBtn.setOnAction(e -> refreshAnalysis());
        exportCsvBtn.setOnAction(e -> exportCsv());
        exportReportBtn.setOnAction(e -> exportAnalysisReport());
        toolbar.getChildren().addAll(refreshBtn, exportCsvBtn, exportReportBtn);

        // Stats row
        HBox statsRow = new HBox(12);
        statsRow.setFillHeight(true);
        VBox statsCard = createCard("📐 Статистика задержек маркеров");
        statsCard.setPrefWidth(300);
        statCount = createStatValue(statsCard, "Маркеров");
        statMean  = createStatValue(statsCard, "Среднее (мс)");
        statStd   = createStatValue(statsCard, "СКО (мс)");
        statMin   = createStatValue(statsCard, "Min (мс)");
        statMax   = createStatValue(statsCard, "Max (мс)");
        statP95   = createStatValue(statsCard, "P95 (мс)");

        // Histogram
        CategoryAxis xAxis = new CategoryAxis();
        NumberAxis yAxis = new NumberAxis();
        xAxis.setLabel("Задержка (мс)");
        xAxis.setStyle("-fx-tick-label-fill: " + TEXT_SECONDARY + ";");
        yAxis.setLabel("Количество");
        yAxis.setStyle("-fx-tick-label-fill: " + TEXT_SECONDARY + ";");
        jitterChart = new BarChart<>(xAxis, yAxis);
        jitterChart.setTitle("Распределение джиттера");
        jitterChart.setAnimated(true);
        jitterChart.setLegendVisible(false);
        jitterChart.setStyle("-fx-background-color: transparent;");
        jitterChart.setBarGap(2);
        jitterChart.setCategoryGap(4);
        HBox.setHgrow(jitterChart, Priority.ALWAYS);
        statsRow.getChildren().addAll(statsCard, jitterChart);

        // Log table
        VBox tableCard = createCard("📋 Журнал событий");
        VBox.setVgrow(tableCard, Priority.ALWAYS);
        logData = FXCollections.observableArrayList();
        logTable = createLogTable();
        logTable.setItems(logData);
        VBox.setVgrow(logTable, Priority.ALWAYS);
        tableCard.getChildren().add(logTable);

        VBox.setVgrow(statsRow, Priority.NEVER);
        VBox.setVgrow(tableCard, Priority.ALWAYS);
        content.getChildren().addAll(toolbar, statsRow, tableCard);

        ScrollPane scroll = new ScrollPane(content);
        scroll.setFitToWidth(true);
        scroll.setStyle("-fx-background-color: " + BG_DARK + "; -fx-border-color: transparent;");
        tab.setContent(scroll);
        return tab;
    }

    @SuppressWarnings("unchecked")
    private TableView<EventLogger.LogEntry> createLogTable() {
        TableView<EventLogger.LogEntry> table = new TableView<>();
        table.setColumnResizePolicy(TableView.CONSTRAINED_RESIZE_POLICY);
        String tableStyle = "-fx-background-color: " + BG_CARD + "; -fx-background-radius: 8; " +
                "-fx-border-color: #3A3A3C; -fx-border-radius: 8; -fx-control-inner-background: " + BG_CARD + "; " +
                "-fx-table-cell-border-color: #3A3A3C;";
        table.setStyle(tableStyle);
        table.setPrefHeight(300);

        TableColumn<EventLogger.LogEntry, String> colTime = new TableColumn<>("Время (ns)");
        colTime.setCellValueFactory(p -> new SimpleStringProperty(String.valueOf(p.getValue().nanoTime)));
        colTime.setPrefWidth(160);

        TableColumn<EventLogger.LogEntry, String> colType = new TableColumn<>("Тип события");
        colType.setCellValueFactory(p -> new SimpleStringProperty(p.getValue().type.toString()));
        colType.setPrefWidth(180);

        TableColumn<EventLogger.LogEntry, String> colMsg = new TableColumn<>("Сообщение");
        colMsg.setCellValueFactory(p -> new SimpleStringProperty(p.getValue().message));
        colMsg.setPrefWidth(400);

        TableColumn<EventLogger.LogEntry, String> colDelay = new TableColumn<>("Задержка (мс)");
        colDelay.setCellValueFactory(p -> new SimpleStringProperty(
                String.format("%.3f", p.getValue().delayMs)));
        colDelay.setPrefWidth(120);

        table.getColumns().addAll(colTime, colType, colMsg, colDelay);
        return table;
    }

    // ── STATUS BAR ──────────────────────────────────────────────────────────

    private HBox createStatusBar() {
        HBox bar = new HBox(16);
        bar.setAlignment(Pos.CENTER_LEFT);
        bar.setPadding(new Insets(8, 24, 8, 24));
        bar.setStyle("-fx-background-color: " + BG_CARD + "; -fx-border-color: #3A3A3C; -fx-border-width: 1 0 0 0;");
        Label versionLabel = new Label("v2.0 — Эксплуатационная практика 2026 | Глушко И.И. гр. 23201");
        versionLabel.setTextFill(Color.web(TEXT_SECONDARY));
        versionLabel.setFont(Font.font("System", 11));
        bar.getChildren().add(versionLabel);
        return bar;
    }

    // ── EVENT HANDLERS ───────────────────────────────────────────────────────

    private void onStartStop() {
        if (manager.getState() == ExperimentManager.State.RUNNING) {
            manager.stopExperiment();
            startStopButton.setText("▶  Запустить");
            startStopButton.setStyle(primaryButtonStyle(ACCENT_COLOR));
            statusIndicator.setFill(Color.web("#8E8E93"));
            stimulusDisplay.setText("Остановлено");
            stimulusDisplay.setTextFill(Color.web(TEXT_SECONDARY));
        } else {
            manager.prepare();
            manager.startExperiment();
            startStopButton.setText("⏹  Остановить");
            startStopButton.setStyle(primaryButtonStyle(DANGER_COLOR));
            statusIndicator.setFill(Color.web(SUCCESS_COLOR));
            progressBar.setProgress(0);
            progressLabel.setText("0 / " + config.getStimulusCount());
        }
    }

    private void onStimulusPresented(VisualStimulus stimulus) {
        stimulusDisplay.setText(stimulus.getText());
        javafx.scene.paint.Color c = stimulus.getTextColor();
        String cssColor = String.format("rgb(%d,%d,%d)",
                (int)(c.getRed()*255), (int)(c.getGreen()*255), (int)(c.getBlue()*255));
        stimulusDisplay.setStyle("-fx-text-fill: " + cssColor + ";");
        markerCountLabel.setText(String.valueOf(manager.getTimestampModule().getMarkersSent()));
        meanDelayLabel.setText(String.format("%.2f мс", manager.getTimestampModule().getMeanDelayMs()));
    }

    private void onStimulusHidden(String ignored) {
        stimulusDisplay.setText("+");
        stimulusDisplay.setStyle("-fx-text-fill: " + TEXT_SECONDARY + ";");
    }

    private void onExperimentFinished() {
        startStopButton.setText("▶  Запустить");
        startStopButton.setStyle(primaryButtonStyle(ACCENT_COLOR));
        statusIndicator.setFill(Color.web(ACCENT_COLOR));
        stimulusDisplay.setText("Эксперимент завершён");
        stimulusDisplay.setStyle("-fx-text-fill: " + SUCCESS_COLOR + ";");
        showInfo("Эксперимент завершён", "Данные сохранены в " + config.getLogDirectory());
    }

    private void onStatusChanged(String status) {
        statusLabel.setText(status);
    }

    private void onProgressChanged(double progress) {
        progressBar.setProgress(progress);
        int total = config.getStimulusCount();
        int done = (int)(progress * total);
        progressLabel.setText(done + " / " + total);
    }

    private void applySettings() {
        config.setStimulusCount(stimulusCountSpinner.getValue());
        config.setStimulusIntervalMs(intervalSpinner.getValue());
        config.setStimulusDurationMs(durationSpinner.getValue());
        config.setEmulationMode(emulationRadio.isSelected());
        config.setEmulationBaseDelayMs(baseDelaySpinner.getValue());
        config.setEmulationJitterStdMs(jitterStdSpinner.getValue());
        config.setEmulationOutlierProbability(outlierProbSpinner.getValue());
        config.setEmulationOutlierMaxMs(outlierMaxSpinner.getValue());
        config.setPortName(portField.getText());
        config.setExperimentId(experimentIdField.getText());
        config.setLogDirectory(logDirField.getText());

        boolean emu = config.isEmulationMode();
        modeLabel.setText(emu ? "⚡ ЭМУЛЯЦИЯ" : "🔌 РЕАЛЬНЫЙ");
        String modeStyle = "-fx-background-color: " + (emu ? WARNING_COLOR : SUCCESS_COLOR) +
                "; -fx-text-fill: white; -fx-font-weight: bold; -fx-font-size: 11px; " +
                "-fx-padding: 4 10 4 10; -fx-background-radius: 8;";
        modeLabel.setStyle(modeStyle);

        showInfo("Настройки применены", "Параметры эксперимента обновлены.");
    }

    private void refreshAnalysis() {
        logData.setAll(logger.getEntries());
        JitterAnalyzer.Stats stats = manager.getAnalysisStats();
        statCount.setText(String.valueOf(stats.count));
        statMean.setText(stats.count > 0 ? String.format("%.3f", stats.mean) : "—");
        statStd.setText(stats.count > 0 ? String.format("%.3f", stats.std) : "—");
        statMin.setText(stats.count > 0 ? String.format("%.3f", stats.min) : "—");
        statMax.setText(stats.count > 0 ? String.format("%.3f", stats.max) : "—");
        statP95.setText(stats.count > 0 ? String.format("%.3f", stats.p95) : "—");

        // Update histogram
        jitterChart.getData().clear();
        if (stats.count > 0) {
            Map<String, Long> hist = JitterAnalyzer.buildHistogram(stats, 12);
            XYChart.Series<String, Number> series = new XYChart.Series<>();
            series.setName("Задержка");
            hist.forEach((bin, count) ->
                    series.getData().add(new XYChart.Data<>(bin, count)));
            jitterChart.getData().add(series);
            // Style bars
            Platform.runLater(() -> jitterChart.lookupAll(".bar").forEach(node ->
                    node.setStyle("-fx-bar-fill: " + ACCENT_COLOR + "; -fx-background-radius: 3;")));
        }
    }

    private void exportCsv() {
        try {
            String path = logger.exportToCsv();
            showInfo("Экспорт завершён", "CSV сохранён:\n" + path);
        } catch (IOException e) {
            showError("Ошибка экспорта", e.getMessage());
        }
    }

    private void exportAnalysisReport() {
        JitterAnalyzer.Stats stats = manager.getAnalysisStats();
        try {
            String path = JitterAnalyzer.exportReport(stats,
                    config.getLogDirectory(), config.getExperimentId() + "_analysis");
            showInfo("Отчёт сохранён", path);
        } catch (IOException e) {
            showError("Ошибка экспорта", e.getMessage());
        }
    }

    // ── UI HELPERS ───────────────────────────────────────────────────────────

    private VBox createCard(String title) {
        VBox card = new VBox(12);
        card.setPadding(new Insets(16));
        String cardStyle = "-fx-background-color: " + BG_CARD + "; -fx-background-radius: 12; " +
                "-fx-border-color: #3A3A3C; -fx-border-radius: 12; -fx-border-width: 1;";
        card.setStyle(cardStyle);
        if (title != null && !title.isEmpty()) {
            Label titleLabel = new Label(title);
            titleLabel.setFont(Font.font("System", FontWeight.BOLD, 13));
            titleLabel.setTextFill(Color.WHITE);
            card.getChildren().add(titleLabel);
            Separator sep = new Separator();
            sep.setStyle("-fx-background-color: #3A3A3C;");
            card.getChildren().add(sep);
        }
        return card;
    }

    private Label createStatRow(VBox card, String label, String defaultVal) {
        HBox row = new HBox();
        Label lbl = new Label(label);
        lbl.setTextFill(Color.web(TEXT_SECONDARY));
        lbl.setFont(Font.font("System", 12));
        Label val = new Label(defaultVal);
        val.setFont(Font.font("System", FontWeight.BOLD, 13));
        val.setTextFill(Color.WHITE);
        row.getChildren().addAll(lbl, createSpacer(), val);
        card.getChildren().add(row);
        return val;
    }

    private Label createStatValue(VBox card, String label) {
        VBox row = new VBox(2);
        Label lbl = new Label(label);
        lbl.setFont(Font.font("System", 11));
        lbl.setTextFill(Color.web(TEXT_SECONDARY));
        Label val = new Label("—");
        val.setFont(Font.font("System", FontWeight.BOLD, 20));
        val.setTextFill(Color.web(ACCENT_COLOR));
        row.getChildren().addAll(lbl, val);
        card.getChildren().add(row);
        return val;
    }

    private void addFormRow(VBox parent, String label, javafx.scene.Node control) {
        VBox row = new VBox(4);
        Label lbl = new Label(label);
        lbl.setFont(Font.font("System", 12));
        lbl.setTextFill(Color.web(TEXT_SECONDARY));
        if (control instanceof Control) ((Control) control).setMaxWidth(Double.MAX_VALUE);
        row.getChildren().addAll(lbl, control);
        parent.getChildren().add(row);
    }

    private Spinner<Integer> createIntSpinner(int min, int max, int init) {
        Spinner<Integer> s = new Spinner<>(min, max, init, 1);
        s.setEditable(true);
        s.setStyle(inputStyle());
        return s;
    }

    private Spinner<Double> createDoubleSpinner(double min, double max, double init, double step) {
        Spinner<Double> s = new Spinner<>(
                new SpinnerValueFactory.DoubleSpinnerValueFactory(min, max, init, step));
        s.setEditable(true);
        s.setStyle(inputStyle());
        return s;
    }

    private TextField createTextField(String text) {
        TextField tf = new TextField(text);
        tf.setStyle(inputStyle());
        return tf;
    }

    private RadioButton createRadio(String text, ToggleGroup group) {
        RadioButton rb = new RadioButton(text);
        rb.setToggleGroup(group);
        rb.setTextFill(Color.web(TEXT_PRIMARY));
        rb.setStyle("-fx-font-size: 13px;");
        return rb;
    }

    private Button createToolbarButton(String text) {
        Button b = new Button(text);
        b.setStyle(secondaryButtonStyle());
        return b;
    }

    private Region createSpacer() {
        Region r = new Region();
        HBox.setHgrow(r, Priority.ALWAYS);
        return r;
    }

    private String primaryButtonStyle(String color) {
        return "-fx-background-color: " + color + "; -fx-text-fill: white; -fx-font-weight: bold; " +
                "-fx-background-radius: 10; -fx-cursor: hand; -fx-font-size: 14px;";
    }

    private String secondaryButtonStyle() {
        return "-fx-background-color: " + BG_INPUT + "; -fx-text-fill: white; -fx-background-radius: 8; " +
                "-fx-cursor: hand; -fx-font-size: 12px; -fx-padding: 6 14 6 14;";
    }

    private String inputStyle() {
        return "-fx-background-color: " + BG_INPUT + "; -fx-text-fill: white; -fx-background-radius: 6; " +
                "-fx-border-color: #3A3A3C; -fx-border-radius: 6; -fx-prompt-text-fill: " + TEXT_SECONDARY + ";";
    }

    private void applyGlobalStyle(Scene scene) {
        String globalStyle = "-fx-font-family: 'System'; -fx-base: " + BG_DARK + "; " +
                "-fx-control-inner-background: " + BG_INPUT + "; -fx-focused-base: " + ACCENT_COLOR + "; " +
                "-fx-selection-bar: " + ACCENT_COLOR + "; -fx-selection-bar-non-focused: #3A3A3C;";
        scene.getRoot().setStyle(globalStyle);
    }

    private void showInfo(String title, String msg) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }

    private void showError(String title, String msg) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }
}