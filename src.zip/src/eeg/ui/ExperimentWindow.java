package eeg.ui;

import eeg.stimulus.Stimulus;
import eeg.input.ResponseRecorder;

import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;

public class ExperimentWindow extends JFrame {
    private JLabel stimulusLabel;
    private ResponseRecorder responseRecorder;

    public ExperimentWindow(eeg.experiment.ExperimentManager manager) {
        super("EEG Experiment");
        setSize(800, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        stimulusLabel = new JLabel("Waiting for experiment to start...", SwingConstants.CENTER);
        stimulusLabel.setFont(new Font("Arial", Font.BOLD, 48));
        add(stimulusLabel, BorderLayout.CENTER);

        addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (responseRecorder != null) {
                    responseRecorder.recordResponse(KeyEvent.getKeyText(e.getKeyCode()));
                }
            }
        });
    }

    public void setResponseHandler(ResponseRecorder responseRecorder) {
        this.responseRecorder = responseRecorder;
    }

    public void showStimulus(Stimulus stimulus) {
        SwingUtilities.invokeLater(() -> {
            stimulusLabel.setText(stimulus.getName());
            // Для демонстрации: через 1 секунду очистим надпись
            Timer timer = new Timer(1000, e -> stimulusLabel.setText(""));
            timer.setRepeats(false);
            timer.start();
        });
    }

    public void showWindow() {
        SwingUtilities.invokeLater(() -> setVisible(true));
    }
}
