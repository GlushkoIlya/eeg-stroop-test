package eeg.input;

import eeg.log.EventLogger;

/**
 * Регистратор ответов испытуемого.
 * Фиксирует нажатия клавиш с нанесекундной точностью.
 */
public class ResponseRecorder {

    private final EventLogger logger;
    private long lastStimulusNano = 0;

    public ResponseRecorder(EventLogger logger) {
        this.logger = logger;
    }

    public void setStimulusTime(long nanoTime) {
        this.lastStimulusNano = nanoTime;
    }

    /**
     * Записать ответ испытуемого.
     * @param key название клавиши
     * @return время реакции в мс (или -1 если нет стимула)
     */
    public double recordResponse(String key) {
        long responseNano = System.nanoTime();
        double reactionTimeMs = lastStimulusNano > 0
            ? (responseNano - lastStimulusNano) / 1_000_000.0
            : -1;

        logger.logEvent(EventLogger.EventType.RESPONSE_RECORDED,
            "Key=" + key + " RT=" + String.format("%.1f", reactionTimeMs) + "ms",
            reactionTimeMs > 0 ? reactionTimeMs : 0);

        return reactionTimeMs;
    }
}
