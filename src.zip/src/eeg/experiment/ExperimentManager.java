package eeg.experiment;

import eeg.analysis.JitterAnalyzer;
import eeg.input.ResponseRecorder;
import eeg.log.EventLogger;
import eeg.stimulus.VisualStimulus;
import eeg.sync.TimestampModule;
import javafx.application.Platform;
import javafx.scene.paint.Color;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.function.Consumer;

/**
 * Центральный менеджер эксперимента.
 * Координирует работу всех модулей: конфигурацию, сессию, логирование,
 * диспетчеризацию стимулов, генерацию меток и регистрацию ответов.
 */
public class ExperimentManager {

    // Состояния эксперимента
    public enum State { IDLE, RUNNING, PAUSED, FINISHED }

    private final ExperimentConfig config;
    private final EventLogger logger;
    private final TimestampModule timestampModule;
    private final ResponseRecorder responseRecorder;
    private ExperimentSession session;

    private ScheduledExecutorService scheduler;
    private ScheduledFuture<?> currentTask;
    private volatile State state = State.IDLE;
    private int currentStimulusIndex = 0;

    // Callbacks для UI (вызываются на JavaFX Application Thread)
    private Consumer<VisualStimulus> onStimulusPresented;
    private Consumer<String> onStimulusHidden;
    private Runnable onExperimentFinished;
    private Consumer<String> onStatusChanged;
    private Consumer<Double> onProgressChanged;

    // Список стимулов (можно расширить для загрузки из JSON)
    private final List<VisualStimulus> stimuli = new ArrayList<>();

    public ExperimentManager(ExperimentConfig config, EventLogger logger) {
        this.config = config;
        this.logger = logger;
        this.timestampModule = new TimestampModule(config, logger);
        this.responseRecorder = new ResponseRecorder(logger);
    }

    public void setCallbacks(
        Consumer<VisualStimulus> onStimulusPresented,
        Consumer<String> onStimulusHidden,
        Runnable onExperimentFinished,
        Consumer<String> onStatusChanged,
        Consumer<Double> onProgressChanged) {
        this.onStimulusPresented = onStimulusPresented;
        this.onStimulusHidden = onStimulusHidden;
        this.onExperimentFinished = onExperimentFinished;
        this.onStatusChanged = onStatusChanged;
        this.onProgressChanged = onProgressChanged;
    }

    /** Подготовка к запуску: генерация списка стимулов. */
    public void prepare() {
        stimuli.clear();
        timestampModule.reset();
        String[] words = {"КРАСНЫЙ", "СИНИЙ", "ЗЕЛЁНЫЙ", "ЖЁЛТЫЙ", "БЕЛЫЙ"};
        Color[] colors = {Color.RED, Color.BLUE, Color.GREEN, Color.YELLOW, Color.WHITE};
        for (int i = 0; i < config.getStimulusCount(); i++) {
            String word = words[i % words.length];
            Color color = colors[(i + 2) % colors.length]; // несовпадение для задачи Струпа
            stimuli.add(new VisualStimulus("S" + (i + 1), i + 1, word, color, Color.BLACK));
        }
    }

    public void startExperiment() {
        if (state == State.RUNNING) return;
        currentStimulusIndex = 0;
        session = new ExperimentSession(config.getExperimentId());
        logger.configure(config.getLogDirectory(), session.getSessionId());
        logger.clear();
        session.startSession();
        logger.logEvent(EventLogger.EventType.SESSION_START, "Experiment started, mode=" +
            (config.isEmulationMode() ? "EMULATION" : "HARDWARE"));

        state = State.RUNNING;
        scheduler = Executors.newSingleThreadScheduledExecutor(r -> {
            Thread t = new Thread(r, "EEG-Scheduler");
            t.setPriority(Thread.MAX_PRIORITY);
            return t;
        });

        updateStatus("Эксперимент запущен");
        scheduleNextStimulus(config.getStimulusIntervalMs() / 2); // небольшая начальная задержка
    }

    private void scheduleNextStimulus(long delayMs) {
        if (state != State.RUNNING) return;
        if (currentStimulusIndex >= stimuli.size()) {
            finishExperiment();
            return;
        }
        currentTask = scheduler.schedule(this::presentCurrentStimulus, delayMs, TimeUnit.MILLISECONDS);
    }

    private void presentCurrentStimulus() {
        if (state != State.RUNNING) return;
        VisualStimulus stimulus = stimuli.get(currentStimulusIndex);
        long presentedNano = System.nanoTime();

        // Отправка маркера синхронизации
        double markerDelay = timestampModule.sendMarker(stimulus.getCode());

        logger.logEvent(EventLogger.EventType.STIMULUS_PRESENTED,
            "Stimulus=" + stimulus.getName() + " text=" + stimulus.getText() +
            " markerDelay=" + String.format("%.3f", markerDelay) + "ms", markerDelay);

        responseRecorder.setStimulusTime(presentedNano);

        double progress = (double)(currentStimulusIndex + 1) / stimuli.size();

        // Обновление UI (Platform.runLater для JavaFX)
        Platform.runLater(() -> {
            if (onStimulusPresented != null) onStimulusPresented.accept(stimulus);
            if (onProgressChanged != null) onProgressChanged.accept(progress);
            updateStatus("Стимул " + (currentStimulusIndex + 1) + "/" + stimuli.size());
        });

        // Скрыть стимул через stimulusDurationMs
        scheduler.schedule(() -> {
            logger.logEvent(EventLogger.EventType.STIMULUS_HIDDEN,
                "Stimulus=" + stimulus.getName() + " hidden");
            Platform.runLater(() -> {
                if (onStimulusHidden != null) onStimulusHidden.accept("");
            });
        }, config.getStimulusDurationMs(), TimeUnit.MILLISECONDS);

        currentStimulusIndex++;
        scheduleNextStimulus(config.getStimulusIntervalMs());
    }

    private void finishExperiment() {
        state = State.FINISHED;
        session.endSession();
        logger.logEvent(EventLogger.EventType.SESSION_END,
            "Experiment finished, markers=" + timestampModule.getMarkersSent() +
            " meanDelay=" + String.format("%.3f", timestampModule.getMeanDelayMs()) + "ms");

        try {
            logger.exportToCsv();
        } catch (IOException e) {
            logger.logEvent(EventLogger.EventType.ERROR, "CSV export failed: " + e.getMessage());
        }

        scheduler.shutdown();
        Platform.runLater(() -> {
            updateStatus("Эксперимент завершён. Меток: " + timestampModule.getMarkersSent());
            if (onProgressChanged != null) onProgressChanged.accept(1.0);
            if (onExperimentFinished != null) onExperimentFinished.run();
        });
    }

    public void stopExperiment() {
        if (state == State.RUNNING || state == State.PAUSED) {
            state = State.IDLE;
            if (currentTask != null) currentTask.cancel(false);
            if (scheduler != null) scheduler.shutdownNow();
            session.endSession();
            logger.logEvent(EventLogger.EventType.SESSION_END, "Experiment stopped by user");
            Platform.runLater(() -> updateStatus("Эксперимент остановлен"));
        }
    }

    public void recordKeyResponse(String key) {
        if (state == State.RUNNING) {
            responseRecorder.recordResponse(key);
        }
    }

    public JitterAnalyzer.Stats getAnalysisStats() {
        return JitterAnalyzer.analyze(logger);
    }

    private void updateStatus(String msg) {
        if (onStatusChanged != null) onStatusChanged.accept(msg);
    }

    public State getState() { return state; }
    public ExperimentConfig getConfig() { return config; }
    public EventLogger getLogger() { return logger; }
    public TimestampModule getTimestampModule() { return timestampModule; }
    public ExperimentSession getSession() { return session; }
}
