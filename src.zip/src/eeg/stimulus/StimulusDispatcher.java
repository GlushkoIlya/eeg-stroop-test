package eeg.stimulus;

import eeg.ui.ExperimentWindow;
import eeg.log.EventLogger;

public class StimulusDispatcher {
    private final eeg.log.EventLogger logger;

    public StimulusDispatcher(eeg.log.EventLogger logger) {
        this.logger = logger;
    }

    public void dispatch(Stimulus stimulus, ExperimentWindow window) {
        logger.logEvent(EventLogger.EventType.STIMULUS_PRESENTED,
                "Stimulus dispatched: " + stimulus.getName());
        // В UI показать стимул
        window.showStimulus(stimulus);
    }
}
